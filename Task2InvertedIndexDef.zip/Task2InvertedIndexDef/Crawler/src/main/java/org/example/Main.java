package org.example;

public class Main {
    public static void main(String[] args) {
        Controller controller = new Controller(10);
        controller.run();
    }
}